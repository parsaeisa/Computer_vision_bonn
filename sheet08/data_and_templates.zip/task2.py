import numpy as np
import utils

# ======================= PPCA =======================
def ppca(covariance, preservation_ratio=0.9):

    # Happy Coding! :)

    pass




# ======================= Covariance =======================

def create_covariance_matrix(kpts, mean_shape):
    # ToDO
    pass





# ======================= Visualization =======================

def visualize_impact_of_pcs(mean, pcs, pc_weights):
    # your part here
    pass





# ======================= Training =======================
def train_statistical_shape_model(kpts):
    # Your code here
    pass




# ======================= Reconstruct =======================
def reconstruct_test_shape(kpts, mean, pcs, pc_weight):
    #ToDo
    pass
